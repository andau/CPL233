sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	var tableId = 0;
	var outliers;
	var predictionConfidence = "";
	var predictivePower = ""; 
    
    var TIME_VALUE_CORRIG = 2061584444; 

	var  MMS_BASE_URL = "/iotmms/com.sap.iotservices.mms/v1/api/http/app.svc/";
	var DB_USERNAME = "SYSTEM";
	var IOT_TABLENAME = "T_IOT_B7B6B10CA55173358ECD";
	var IOT_TABLE_MAX_LINES = 1000;
	var IOT_TABLE_ORDER_COLUMN = "C_MILLISECONDS";

	var MESSAGE_TOAST_SHOW_DURATION = 3000;
	var MESSAGE_TOAST_WIDTH = "30em";

	var URL_PREDICTIVE_API_ROOT = "/predictiveApi";
	var URL_PREDICTIVE_DATASET_REGISTER = "/api/analytics/dataset/sync";
	var URL_PREDICTIVE_GET_OUTLIERS = "/api/analytics/outliers/sync";

	var MAX_NUMBER_OF_OUTLIERS = 10;
	var NUMBER_OF_REASONS = 1;
	var TARGET_COLUMN = "C_YVALUE";
	
	var MAX_DEVIATION = 0; 

	return Controller.extend("com.demo.controller.Main", {
		onInit: function() {},
		_mapResults: function(response) {
			var oModel = this.getView().getModel();
			oModel.setProperty("/items", response.d.results);
		},
		_loadIoT: function() {
			var oView = this.getView();
			var sUrl = MMS_BASE_URL + DB_USERNAME + "." + IOT_TABLENAME + "?$orderby=" + IOT_TABLE_ORDER_COLUMN + "&$top=" +
				IOT_TABLE_MAX_LINES + "&$format=json";
			oView.setBusy(true);
			var self = this;

			$.get(sUrl).done(function(results) {
					oView.setBusy(false);
					self._mapResults(results);
				})
				.fail(function(err) {
					oView.setBusy(false);
					if (err !== undefined) {
						var oErrorResponse = $.parseJSON(err.responseText);
						sap.m.MessageToast(oErrorResponse.message, {
							duration: MESSAGE_TOAST_SHOW_DURATION
						});
					} else {
						sap.m.MessageToast.show("Unknown error!");
					}
				});
		},
		_eventHandler: function(buttonType) {
			var self = this;
			var frequency;
			switch (buttonType) {
				case "start":
					if (sap.ui.getCore().byId("dropdownId").getSelectedItemId() === "justOnceId") {
						// Call _loadIoT() only once
						self._loadIoT();
						self._calculateOutliers();
					} else {
						// Determine the frequency
						switch (sap.ui.getCore().byId("dropdownId").getSelectedItemId()) {
							case "twoId":
								frequency = 2000;
								break;
							case "fiveId":
								frequency = 5000;
								break;
							case "tenId":
								frequency = 10000;
								break;
						}
						sap.ui.getCore().byId("startButtonId").setProperty("enabled", false);
						sap.ui.getCore().byId("stopButtonId").setProperty("enabled", true);
						self.intervalId = setInterval(function() {
							self._loadIoT();
							self._calculateOutliers();

						}, frequency);
					}
					break;
				case "stop":
					// stop the interval
					clearInterval(self.intervalId);
					sap.ui.getCore().byId("startButtonId").setProperty("enabled", true);
					sap.ui.getCore().byId("stopButtonId").setProperty("enabled", false);
					break;
			}
		},
		_calculateOutliers: function() {
			if (tableId === 0) {
				tableId = this._registerTable();
			}
			var outlierMessage = "Outlieranalysis for " + TARGET_COLUMN + ":\n" 
			                     + this._getOutliers(tableId);

			sap.m.MessageToast.show(outlierMessage, {
				duration: MESSAGE_TOAST_SHOW_DURATION,
				width: MESSAGE_TOAST_WIDTH
			});
		},

		_registerTable: function() {

			var jsonData = '{ ' + '"location" : { ' + '"schema" : "' + DB_USERNAME + '",' + '"table" : "' + IOT_TABLENAME + '"' + ' }' + ' }';

			var tableId = 0;

			$.ajax({
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json'
				},
				type: "POST",
				url: URL_PREDICTIVE_API_ROOT + URL_PREDICTIVE_DATASET_REGISTER,
				dataType: "json",
				data: jsonData,
				async: false,
				success: function(data) {
					tableId = data.ID;
					sap.log.debug("success register dataset");
				},
				error: function() {
					sap.log.error("error register dataset");
				}
			});

			return tableId;
		},

		_getOutliers: function(tableId) {
			var outlierErrormessage = "";

            
			var jsonData = '{' 
			                + '"datasetID" : ' + tableId + ',' 
			                + '"targetColumn" : "' + TARGET_COLUMN + '" ,' 
			                //+ '"skippedVariables" : ["G_DEVICE", "G_CREATED", "C_ZVALUE"],' 
			                + '"numberOfOutliers" : ' + MAX_NUMBER_OF_OUTLIERS + ',' 
			                + '"numberOfReasons" : ' + NUMBER_OF_REASONS + '}';

			$.ajax({
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json'
				},
				type: "POST",
				url: URL_PREDICTIVE_API_ROOT + URL_PREDICTIVE_GET_OUTLIERS,
				dataType: "json",
				data: jsonData,
				success: function(data) {
					outliers = data.outliers;
					predictionConfidence = data.modelPerformance.predictionConfidence;
					predictivePower = data.modelPerformance.predictivePower; 
					sap.log.debug("success call outliers");
				},
				error: function(request) {
					outlierErrormessage = request.responseText;
					sap.log.error("error call outliers");
				}
			});
			if (outlierErrormessage === "") {
				var outlierMessage = "predictionConfidence: " + predictionConfidence + ", predictivePower: " + predictivePower + "\n\n"; 
				outlierMessage += this._evaluateOutlierMessage(outliers); 
				return outlierMessage; 
			} else {
				return outlierErrormessage;
			}
		},

		_evaluateOutlierMessage: function(outliers) {
			var outlierMessage = "";
			var existsSignificantOutliers = false;
			for (var i = 0; i < outliers.length; i++) {
				var outlier = outliers[i];
				var deviationAbs = Math.abs(outlier.realValue - outlier.predictedValue);
				if (deviationAbs > MAX_DEVIATION) {
					var outlierPosition = 	outlier.dataPoint.C_MILLISECONDS + TIME_VALUE_CORRIG; 

					outlierMessage += " Outlier " + (i + 1) + " at " + outlierPosition + ";";
					existsSignificantOutliers = true;
				}
			}
			if (existsSignificantOutliers === false) {
				outlierMessage += " No outliers";
			}
			return outlierMessage;
		}

	});

});