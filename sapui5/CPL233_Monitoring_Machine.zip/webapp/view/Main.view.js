sap.ui.jsview("com.demo.view.Main", {

	getControllerName: function() {
		return "com.demo.controller.Main";
	},

	createContent: function(oController) {

		var X_VALUE_NAME = "C_XVALUE";
		var Y_VALUE_NAME = "C_YVALUE";
		var Z_VALUE_NAME = "C_ZVALUE";
		var TIME_VALUE_NAME = "C_MILLISECONDS";
		var TIME_VALUE_CORRIG = 2061584444; 

		// Page 1
		var oLayout = new sap.ui.layout.form.SimpleForm("formId", {
			content: [

				new sap.ui.commons.Label({
					text: "Select Refresh Rate:",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.DropdownBox("dropdownId", {
					width: "300px",
					required: true,
					editable: true,
					items: [
						new sap.ui.core.ListItem("justOnceId", {
							text: 'Just Once'
						}),
						new sap.ui.core.ListItem("twoId", {
							text: '2 Seconds'
						}),
						new sap.ui.core.ListItem("fiveId", {
							text: '5 Seconds'
						}),
						new sap.ui.core.ListItem("tenId", {
							text: '10 Seconds'
						})
					]
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),

				new sap.ui.commons.Label({
					text: "",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Button("startButtonId", {
					text: "Start",
					width: "100px",
					press: function() {
						oController._eventHandler("start");
						app.to("page2");
					}
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Label({
					text: "",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Button("stopButtonId", {
					text: "Stop",
					width: "100px",
					enabled: false,
					press: function() {
						oController._eventHandler("stop");
					}
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop")
			]
		});
		//End of Page 1

		// Page 2
		// Cells
		var oCellX = new sap.m.Text({
			text: "{" + X_VALUE_NAME + "}"
		});
		var oCellY = new sap.m.Text({
			text: "{" + Y_VALUE_NAME + "}"
		});
		var oCellZ = new sap.m.Text({
			text: "{" + Z_VALUE_NAME + "}"
		});
		// Corresponding Columns
		var col1 = new sap.m.Column("col1", {
			header: new sap.m.Label({
				text: X_VALUE_NAME
			})
		});
		var col2 = new sap.m.Column("col2", {
			header: new sap.m.Label({
				text: Y_VALUE_NAME
			})
		});
		var col3 = new sap.m.Column("col3", {
			header: new sap.m.Label({
				text: Z_VALUE_NAME
			})
		});
		// Row Template
		var oRow = new sap.m.ColumnListItem();
		oRow.addCell(oCellX).addCell(oCellY).addCell(oCellZ);
		// Table
		var oTable = sap.m.Table("mainTable", {
			inset: false,
			headerText: "Accelerometer data points from IoT Service"
		});
		oTable.addColumn(col1).addColumn(col2).addColumn(col3);
		// Binding
		oTable.bindItems("/items", oRow);
		// End of Page 2

		// Page 3
		var vizFrame = new sap.viz.ui5.controls.VizFrame("graph").addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop");
		vizFrame.setWidth("900px");
		var oDataset = new sap.viz.ui5.data.FlattenedDataset({
			dimensions: [{
				name: "Time",
				value: {
					path: TIME_VALUE_NAME,
					formatter: function(val) {
						if (val === null) {
							return "string null";
						}
						return val + TIME_VALUE_CORRIG;
					}
				}
			}],
			measures: [{
				name: X_VALUE_NAME,
				value: "{" + X_VALUE_NAME + "}"
			}, {
				name: Y_VALUE_NAME,
				value: "{" + Y_VALUE_NAME + "}"
			}, {
				name: Z_VALUE_NAME,
				value: "{" + Z_VALUE_NAME  + "}"  
			}],
			data: {
				path: "/items"

			}
		});
		vizFrame.setDataset(oDataset);
		vizFrame.setVizType('line');

		vizFrame.setVizProperties({
			plotArea: {
				colorPalette: ["#5cbae6", "#b6d957", "#fac364"]
			},
			categoryAxis: {
				title: {
					text: "Time since start (in ms)"
				}
			},
			valueAxis: {
				title: {
					text: "Accelerometer values"
				}
			},
			title: {
				visible: false
			}
		});

		var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': [X_VALUE_NAME, Y_VALUE_NAME, Z_VALUE_NAME]
			}),
			feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "categoryAxis",
				'type': "Dimension",
				'values': ["Time"]
			});

		vizFrame.addFeed(feedValueAxis);
		vizFrame.addFeed(feedCategoryAxis);

		var container = new sap.m.VBox({
			items: [vizFrame],
			width: "100%",
			height: "100%",
			alignItems: "Center"
		});
		// End of Page 3

		// Page Structure	    
		var app = new sap.m.App("myApp", {
			initialPage: "oPage"
		});

		var navButton1 = new sap.m.Button({
			text: "View Table",
			press: function() {
				// navigate to page2
				app.to("page2");
			}
		});

		var navButton2 = new sap.m.Button({
			text: "View Chart",
			press: function() {
				// navigate to page3
				app.to("page3");
			}
		});

		var page1 = new sap.m.Page("page1", {
			title: "{i18n>page1Title}",
			showNavButton: false,
			content: [navButton1, oLayout]
		});

		var page2 = new sap.m.Page("page2", {
			title: "{i18n>page2Title}",
			content: [navButton2, oTable],
			showNavButton: true,
			navButtonPress: function() {
				// go back to the previous page
				app.back();
			}
		});

		var page3 = new sap.m.Page("page3", {
			title: "{i18n>page3Title}",
			content: [container],
			showNavButton: true,
			navButtonPress: function() {
				// go back to the previous page
				app.back();
			}
		});
		// End of Page Structure

		app.addPage(page1).addPage(page2).addPage(page3);
		return app;
	}

});